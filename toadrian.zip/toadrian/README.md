RUN:

python3 -m venv env
source env/bin/activate
pip3 install -r requirements.txt
python3 myhdf2wav.py sweep_p1intensity_2021-08-31T162239Z.h5

Hadam by to malo fungovat

ked to spustis da ti to na vyber ktory dataset z .h5 suboru chces citat - chces "/Acquisition/Raw[0]/RawData", je tam input na cislo tak mu tam len hod 5 on si to pekne nacita

Example:
(env) jsencak@jsencak-mac optoviz % python3 myhdf2wav.py -fs 10000 data/das-merania/sweep_p1intensity_2021-08-31T17_22_39+0100/sweep_p1intensity_2021-08-31T162239Z.h5
Converting data/das-merania/sweep_p1intensity_2021-08-31T17_22_39+0100/sweep_p1intensity_2021-08-31T162239Z.h5 to data/das-merania/sweep_p1intensity_2021-08-31T17_22_39+0100/sweep_p1intensity_2021-08-31T162239Z.h5.wav [dataset: None].
0 /Acquisition
1 /Acquisition/Custom
2 /Acquisition/Raw[0]
3 /Acquisition/Raw[0]/Custom
4 /Acquisition/Raw[0]/Custom/SampleCount
5 /Acquisition/Raw[0]/RawData
6 /Acquisition/Raw[0]/RawDataTime
Please choose one dataset path [NUM]: 5
Provided selection is a dataset
<HDF5 dataset "RawData": shape (100, 332032), type "<i2">
24838
<class 'numpy.ndarray'>
[[-17625.         -18475.         -18148.         ... -17196.
  -17343.         -17302.        ]
 [-13743.27460249 -14680.19769346 -13898.83816757 ... -13781.65167419
  -13515.93793069 -13900.01596888]
 [-11169.9572929  -11966.83668095 -10831.79959429 ... -11732.86584097
  -11004.52049592 -11831.56747167]
 ...
 [-27849.91587078 -27933.75493126 -28303.25946052 ... -27398.52697158
  -27714.50860614 -27433.9527482 ]
 [-25461.04751633 -25780.60877339 -26110.45447557 ... -24782.48709421
  -25223.3198014  -24828.13184375]
 [-21849.30644373 -22458.09605572 -22540.02463427 ... -21162.69558311
  -21558.83076915 -21237.43238614]]
INFLOAT
[[-17625.     -18475.     -18148.     ... -17196.     -17343.
  -17302.    ]
 [-13743.274  -14680.197  -13898.838  ... -13781.651  -13515.9375
  -13900.016 ]
 [-11169.957  -11966.837  -10831.8    ... -11732.866  -11004.5205
  -11831.567 ]
 ...
 [-27849.916  -27933.756  -28303.26   ... -27398.527  -27714.508
  -27433.953 ]
 [-25461.047  -25780.61   -26110.455  ... -24782.486  -25223.32
  -24828.133 ]
 [-21849.307  -22458.096  -22540.025  ... -21162.695  -21558.83
  -21237.432 ]]
AFTER INTERP
[[-0.39571778 -0.42332062 -0.41270164 ... -0.38178646 -0.38656013
  -0.3852287 ]
 [-0.2696629  -0.30008847 -0.27471466 ... -0.27090915 -0.26228038
  -0.2747529 ]
 [-0.18609718 -0.211975   -0.17511588 ... -0.20437705 -0.1807248
  -0.20758226]
 ...
 [-0.72776097 -0.73048358 -0.74248282 ... -0.71310261 -0.72336374
  -0.71425302]
 [-0.65018501 -0.66056246 -0.67127384 ... -0.62814948 -0.64246509
  -0.6296318 ]
 [-0.53289761 -0.55266738 -0.55532796 ... -0.51060064 -0.5234647
  -0.51302763]]
Traceback (most recent call last):
  File "/Users/jsencak/Library/CloudStorage/OneDrive-VysokéučenítechnickévBrně/FEKT/diplomka/sofware/optoviz/myhdf2wav.py", line 89, in <module>
    sys.exit(main())
  File "/Users/jsencak/Library/CloudStorage/OneDrive-VysokéučenítechnickévBrně/FEKT/diplomka/sofware/optoviz/myhdf2wav.py", line 83, in main
    write_wav(args.output, data, fs=args.fs)
  File "/Users/jsencak/Library/CloudStorage/OneDrive-VysokéučenítechnickévBrně/FEKT/diplomka/sofware/optoviz/myhdf2wav.py", line 65, in write_wav
    scipy.io.wavfile.write(f, 44100, samples)
  File "/Users/jsencak/Library/CloudStorage/OneDrive-VysokéučenítechnickévBrně/FEKT/diplomka/sofware/optoviz/env/lib/python3.10/site-packages/scipy/io/wavfile.py", line 796, in write
    fmt_chunk_data = struct.pack('<HHIIHH', format_tag, channels, fs,
struct.error: ushort format requires 0 <= number <= (32767 *2 +1)